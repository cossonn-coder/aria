import logging

from agents.base import AgentContext, BaseAgent
from llm_router import LLMRole, router

logger = logging.getLogger(__name__)

CRITIC_PROMPT = """Tu es un agent critique expert, nuancé et bienveillant. Tu parles français avec précision.

IDÉE : {idea}

PLAN PROPOSÉ :
{plan}

Effectue une analyse critique structurée en Markdown :

## ✅ Points solides
Ce qui est bien pensé, réaliste, les forces du plan.

## ⚠️ Risques & angles morts
Ce qui pourrait mal tourner, ce qui a été oublié ou sous-estimé.

## 🔄 Alternatives
D'autres approches possibles, des chemins différents à considérer.

## 💡 Suggestions concrètes
Des améliorations spécifiques et actionnables pour renforcer le plan.

Sois direct, honnête, sans complaisance mais constructif.
"""


class CriticAgent(BaseAgent):
    def run(self, ctx: AgentContext) -> AgentContext:
        if not ctx.plan:
            ctx.critique = "Pas de plan à critiquer."
            return ctx

        prompt = CRITIC_PROMPT.format(
            idea=ctx.raw_idea,
            plan=ctx.plan,
        )
        try:
            response = router.complete(
                prompt=prompt,
                role=LLMRole.CREATIVE,
                temperature=0.6,
                max_tokens=1500,
            )
            ctx.critique = response.text
        except Exception as e:
            logger.error(f"CriticAgent erreur : {e}")
            ctx.critique = f"Critique indisponible : {e}"
        return ctx
