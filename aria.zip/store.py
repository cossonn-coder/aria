"""
MemoryStore — ChromaDB + embeddings Google
Mémoires sémantiques avec validation humaine obligatoire avant persistance.
"""

import hashlib
import json
import logging
from pathlib import Path
from typing import Optional

import chromadb
from chromadb.config import Settings
import google.generativeai as genai

logger = logging.getLogger(__name__)


class MemoryStore:
    def __init__(self):
        from config import config
        self.cfg = config
        genai.configure(api_key=config.gemini_api_key)

        self.client = chromadb.PersistentClient(
            path=config.chroma_path,
            settings=Settings(anonymized_telemetry=False),
        )
        self.collection = self.client.get_or_create_collection(
            name="aria_memories",
            metadata={"hnsw:space": "cosine"},
        )
        self._pending_path = Path(config.pending_path)

    # ── Embeddings ────────────────────────────────────────────────────────────

    def _embed_doc(self, text: str) -> list[float]:
        return genai.embed_content(
            model=self.cfg.embedding_model,
            content=text,
            task_type="retrieval_document",
        )["embedding"]

    def _embed_query(self, text: str) -> list[float]:
        return genai.embed_content(
            model=self.cfg.embedding_model,
            content=text,
            task_type="retrieval_query",
        )["embedding"]

    # ── Mémoires en attente (pending) ─────────────────────────────────────────

    def add_pending(self, memories: list[dict], user_id: int):
        """Stocke des mémoires candidates pour validation humaine."""
        pending = self._load_pending()
        key = str(user_id)
        pending.setdefault(key, [])
        for mem in memories:
            if mem.get("content", "").strip():
                pending[key].append(mem)
        self._save_pending(pending)

    def get_pending(self, user_id: int) -> list[dict]:
        return self._load_pending().get(str(user_id), [])

    def confirm_pending(self, user_id: int, indices: Optional[list[int]] = None) -> int:
        """Valide et stocke les mémoires en attente (toutes ou par indices)."""
        pending = self._load_pending()
        key = str(user_id)
        candidates = pending.get(key, [])
        if not candidates:
            return 0

        to_add = candidates if indices is None else [candidates[i] for i in indices if 0 <= i < len(candidates)]
        added = self._add_to_chroma(to_add, user_id)

        # Retire les validées
        if indices is None:
            pending[key] = []
        else:
            pending[key] = [m for i, m in enumerate(candidates) if i not in indices]
        self._save_pending(pending)
        return added

    def reject_pending(self, user_id: int):
        pending = self._load_pending()
        pending[str(user_id)] = []
        self._save_pending(pending)

    def _load_pending(self) -> dict:
        if self._pending_path.exists():
            try:
                return json.loads(self._pending_path.read_text())
            except Exception:
                return {}
        return {}

    def _save_pending(self, data: dict):
        self._pending_path.write_text(json.dumps(data, ensure_ascii=False, indent=2))

    # ── Persistance ChromaDB ──────────────────────────────────────────────────

    def _md5(self, text: str) -> str:
        return hashlib.md5(text.encode()).hexdigest()

    def _add_to_chroma(self, memories: list[dict], user_id: int) -> int:
        added = 0
        for mem in memories:
            content = mem.get("content", "").strip()
            if not content:
                continue
            doc_id = f"{user_id}_{self._md5(content)}"
            if self.collection.get(ids=[doc_id])["ids"]:
                continue  # doublon
            try:
                embedding = self._embed_doc(content)
                self.collection.add(
                    ids=[doc_id],
                    embeddings=[embedding],
                    documents=[content],
                    metadatas=[{
                        "user_id": str(user_id),
                        "category": mem.get("category", "général"),
                        "importance": int(mem.get("importance", 5)),
                    }],
                )
                added += 1
            except Exception as e:
                logger.error(f"Erreur ajout ChromaDB : {e}")
        return added

    # ── Recherche sémantique ──────────────────────────────────────────────────

    def search(self, query: str, user_id: int, n: Optional[int] = None) -> list[dict]:
        n = n or self.cfg.max_memories_injected
        total = self.collection.count()
        if total == 0:
            return []
        try:
            query_emb = self._embed_query(query)
            results = self.collection.query(
                query_embeddings=[query_emb],
                n_results=min(n * 2, total),
                where={"user_id": str(user_id)},
            )
            memories = []
            for i, doc in enumerate(results["documents"][0]):
                distance = results["distances"][0][i]
                score = 1 - distance
                if score < self.cfg.memory_relevance_threshold:
                    continue
                meta = results["metadatas"][0][i]
                importance = int(meta.get("importance", 5))
                memories.append({
                    "content": doc,
                    "category": meta.get("category", "général"),
                    "importance": importance,
                    "score": round(score, 3),
                    "weighted": round(score * importance, 3),
                })
            memories.sort(key=lambda x: x["weighted"], reverse=True)
            return memories[:n]
        except Exception as e:
            logger.error(f"Erreur recherche : {e}")
            return []

    def format_for_prompt(self, memories: list[dict]) -> str:
        if not memories:
            return ""
        by_cat: dict[str, list[str]] = {}
        for m in memories:
            by_cat.setdefault(m["category"], []).append(m["content"])
        lines = ["## Mémoires pertinentes"]
        for cat, items in by_cat.items():
            lines.append(f"\n### {cat.capitalize()}")
            lines.extend(f"- {c}" for c in items)
        return "\n".join(lines)

    # ── Utilitaires ───────────────────────────────────────────────────────────

    def get_all(self, user_id: int) -> list[dict]:
        try:
            r = self.collection.get(where={"user_id": str(user_id)})
            return [
                {
                    "content": doc,
                    "category": r["metadatas"][i].get("category", "général"),
                    "importance": r["metadatas"][i].get("importance", 5),
                }
                for i, doc in enumerate(r["documents"])
            ]
        except Exception as e:
            logger.error(f"Erreur get_all : {e}")
            return []

    def count(self, user_id: int) -> int:
        try:
            return len(self.collection.get(where={"user_id": str(user_id)})["ids"])
        except Exception:
            return 0

    def reset(self, user_id: int):
        try:
            r = self.collection.get(where={"user_id": str(user_id)})
            if r["ids"]:
                self.collection.delete(ids=r["ids"])
            self.reject_pending(user_id)
        except Exception as e:
            logger.error(f"Erreur reset : {e}")


memory_store = MemoryStore()
