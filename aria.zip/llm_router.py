import time
import logging
import requests
from enum import Enum
from dataclasses import dataclass

logger = logging.getLogger(__name__)


class LLMRole(Enum):
    FAST = "fast"        # Groq → Cerebras → OpenRouter → Gemini
    DEEP = "deep"        # Gemini → SambaNova → OpenRouter → Groq
    CREATIVE = "creative"  # Mistral → OpenRouter → Gemini → Cerebras


FALLBACK_ORDER: dict[LLMRole, list[str]] = {
    LLMRole.FAST:     ["groq", "cerebras", "openrouter", "gemini"],
    LLMRole.DEEP:     ["gemini", "sambanova", "openrouter", "groq"],
    LLMRole.CREATIVE: ["mistral", "openrouter", "gemini", "cerebras"],
}


@dataclass
class LLMResponse:
    text: str
    model_used: str
    role: LLMRole


class LLMRouter:
    def __init__(self):
        from config import config
        self.cfg = config
        self._openrouter_models: list[str] = []
        self._openrouter_last_refresh: float = 0
        self._openrouter_idx: int = 0

    # ── OpenRouter : sélection dynamique des modèles gratuits ─────────────────

    def _refresh_openrouter_models(self):
        elapsed = time.time() - self._openrouter_last_refresh
        if elapsed < self.cfg.openrouter_models_refresh_hours * 3600:
            return
        try:
            resp = requests.get(
                "https://openrouter.ai/api/v1/models",
                headers={"Authorization": f"Bearer {self.cfg.openrouter_api_key}"},
                timeout=15,
            )
            resp.raise_for_status()
            models = resp.json().get("data", [])
            free = [
                (m["id"], m.get("context_length", 0))
                for m in models
                if str(m.get("pricing", {}).get("prompt", "1")) == "0"
                and m.get("context_length", 0) >= 8000
            ]
            free.sort(key=lambda x: x[1], reverse=True)
            self._openrouter_models = [m[0] for m in free[:10]]
            self._openrouter_last_refresh = time.time()
            logger.info(f"OpenRouter : {len(self._openrouter_models)} modèles gratuits chargés")
        except Exception as e:
            logger.warning(f"OpenRouter refresh échoué : {e}")

    def _get_openrouter_model(self) -> str:
        self._refresh_openrouter_models()
        if not self._openrouter_models:
            return "meta-llama/llama-3.1-8b-instruct:free"
        model = self._openrouter_models[self._openrouter_idx % len(self._openrouter_models)]
        self._openrouter_idx += 1
        return model

    # ── Appels providers ──────────────────────────────────────────────────────

    def _call_groq(self, prompt, system, temperature, max_tokens) -> str:
        from groq import Groq
        client = Groq(api_key=self.cfg.groq_api_key)
        messages = ([{"role": "system", "content": system}] if system else []) + \
                   [{"role": "user", "content": prompt}]
        r = client.chat.completions.create(
            model=self.cfg.groq_model,
            messages=messages,
            temperature=temperature,
            max_tokens=max_tokens,
        )
        return r.choices[0].message.content

    def _call_cerebras(self, prompt, system, temperature, max_tokens) -> str:
        from cerebras.cloud.sdk import Cerebras
        client = Cerebras(api_key=self.cfg.cerebras_api_key)
        messages = ([{"role": "system", "content": system}] if system else []) + \
                   [{"role": "user", "content": prompt}]
        r = client.chat.completions.create(
            model=self.cfg.cerebras_model,
            messages=messages,
            temperature=temperature,
            max_tokens=max_tokens,
        )
        return r.choices[0].message.content

    def _call_gemini(self, prompt, system, temperature, max_tokens) -> str:
        import google.generativeai as genai
        genai.configure(api_key=self.cfg.gemini_api_key)
        model = genai.GenerativeModel(
            self.cfg.gemini_model,
            system_instruction=system or None,
            generation_config={"temperature": temperature, "max_output_tokens": max_tokens},
        )
        return model.generate_content(prompt).text

    def _call_mistral(self, prompt, system, temperature, max_tokens) -> str:
        from mistralai import Mistral
        client = Mistral(api_key=self.cfg.mistral_api_key)
        messages = ([{"role": "system", "content": system}] if system else []) + \
                   [{"role": "user", "content": prompt}]
        r = client.chat.complete(
            model=self.cfg.mistral_model,
            messages=messages,
            temperature=temperature,
            max_tokens=max_tokens,
        )
        return r.choices[0].message.content

    def _call_sambanova(self, prompt, system, temperature, max_tokens) -> str:
        messages = ([{"role": "system", "content": system}] if system else []) + \
                   [{"role": "user", "content": prompt}]
        r = requests.post(
            "https://api.sambanova.ai/v1/chat/completions",
            headers={
                "Authorization": f"Bearer {self.cfg.sambanova_api_key}",
                "Content-Type": "application/json",
            },
            json={"model": self.cfg.sambanova_model, "messages": messages,
                  "temperature": temperature, "max_tokens": max_tokens},
            timeout=60,
        )
        r.raise_for_status()
        return r.json()["choices"][0]["message"]["content"]

    def _call_openrouter(self, prompt, system, temperature, max_tokens) -> str:
        model = self._get_openrouter_model()
        messages = ([{"role": "system", "content": system}] if system else []) + \
                   [{"role": "user", "content": prompt}]
        r = requests.post(
            "https://openrouter.ai/api/v1/chat/completions",
            headers={
                "Authorization": f"Bearer {self.cfg.openrouter_api_key}",
                "Content-Type": "application/json",
            },
            json={"model": model, "messages": messages,
                  "temperature": temperature, "max_tokens": max_tokens},
            timeout=60,
        )
        r.raise_for_status()
        return r.json()["choices"][0]["message"]["content"]

    # ── Dispatch ──────────────────────────────────────────────────────────────

    def _dispatch(self, provider: str, prompt, system, temperature, max_tokens) -> str:
        return {
            "groq":       self._call_groq,
            "cerebras":   self._call_cerebras,
            "gemini":     self._call_gemini,
            "mistral":    self._call_mistral,
            "sambanova":  self._call_sambanova,
            "openrouter": self._call_openrouter,
        }[provider](prompt, system, temperature, max_tokens)

    def _model_label(self, provider: str) -> str:
        labels = {
            "groq":      self.cfg.groq_model,
            "cerebras":  self.cfg.cerebras_model,
            "gemini":    self.cfg.gemini_model,
            "mistral":   self.cfg.mistral_model,
            "sambanova": self.cfg.sambanova_model,
            "openrouter": f"openrouter/{self._openrouter_models[0] if self._openrouter_models else 'free'}",
        }
        return labels.get(provider, provider)

    # ── Point d'entrée principal ───────────────────────────────────────────────

    def complete(
        self,
        prompt: str,
        role: LLMRole = LLMRole.FAST,
        system: str = "",
        temperature: float = 0.7,
        max_tokens: int = 1000,
    ) -> LLMResponse:
        last_error = None
        for provider in FALLBACK_ORDER[role]:
            try:
                text = self._dispatch(provider, prompt, system, temperature, max_tokens)
                return LLMResponse(text=text, model_used=self._model_label(provider), role=role)
            except Exception as e:
                logger.warning(f"[{provider}] échec ({role.value}) : {e}")
                last_error = e
        raise RuntimeError(
            f"Tous les providers ont échoué pour le rôle {role.value}. "
            f"Dernière erreur : {last_error}"
        )


router = LLMRouter()
