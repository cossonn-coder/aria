from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class AgentContext:
    user_id: int
    raw_idea: str
    memories: list[dict] = field(default_factory=list)
    answers: list[str] = field(default_factory=list)
    analysis: str = ""
    plan: str = ""
    critique: str = ""
    domain_tags: list[str] = field(default_factory=list)
    extra: dict = field(default_factory=dict)


class BaseAgent(ABC):
    @abstractmethod
    def run(self, ctx: AgentContext) -> AgentContext:
        ...

    def _format_memories(self, ctx: AgentContext) -> str:
        if not ctx.memories:
            return ""
        lines = ["Mémoires pertinentes sur l'utilisateur :"]
        for m in ctx.memories:
            lines.append(f"- [{m.get('category', 'général')}] {m['content']}")
        return "\n".join(lines)

    def _format_answers(self, ctx: AgentContext) -> str:
        if not ctx.answers:
            return "Aucune information complémentaire fournie."
        lines = ["Informations complémentaires fournies par l'utilisateur :"]
        for i, a in enumerate(ctx.answers, 1):
            lines.append(f"{i}. {a}")
        return "\n".join(lines)
