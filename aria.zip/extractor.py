"""
MemoryExtractor — extrait des mémoires structurées depuis une conversation.
Les mémoires extraites sont placées en attente (pending) et jamais écrites
directement dans ChromaDB sans validation de Nico.
"""

import json
import logging
import re

from llm_router import LLMRole, router

logger = logging.getLogger(__name__)

EXTRACTION_PROMPT = """Tu es un assistant chargé d'extraire les informations mémorables d'une conversation.

Analyse la conversation ci-dessous et extrait uniquement les faits durables et utiles à retenir sur l'utilisateur : préférences, projets, décisions, contraintes techniques, informations personnelles pertinentes (non sensibles).

RÈGLES STRICTES :
- Ne stocke JAMAIS : mots de passe, clés API, données médicales précises, informations financières confidentielles
- Ne stocke pas les fragments de conversation ou échanges banals
- Chaque mémoire doit être un fait autonome et réutilisable
- importance : 1 (anecdotique) → 10 (critique à retenir)
- categories possibles : projet, préférence, technique, personnel, contrainte, décision, contexte

Réponds UNIQUEMENT avec un JSON valide, sans texte avant ou après, sans backticks :
{"memories": [{"content": "...", "category": "...", "importance": 5}]}

Si rien à retenir, réponds : {"memories": []}

CONVERSATION :
{conversation}
"""


class MemoryExtractor:
    def extract(self, conversation: list[dict]) -> list[dict]:
        """
        conversation : liste de {"role": "user"|"assistant", "content": "..."}
        Retourne une liste de mémoires candidates (non encore validées).
        """
        if not conversation:
            return []

        conv_text = "\n".join(
            f"{m['role'].upper()} : {m['content']}" for m in conversation
        )
        prompt = EXTRACTION_PROMPT.format(conversation=conv_text)

        try:
            response = router.complete(
                prompt=prompt,
                role=LLMRole.FAST,
                temperature=0.1,
                max_tokens=800,
            )
            return self._parse(response.text)
        except Exception as e:
            logger.error(f"Erreur extraction mémoire : {e}")
            return []

    def _parse(self, raw: str) -> list[dict]:
        # Nettoyage robuste : supprime les blocs ```json ... ```
        clean = re.sub(r"```(?:json)?", "", raw).strip()
        # Extrait le premier objet JSON trouvé
        match = re.search(r"\{.*\}", clean, re.DOTALL)
        if not match:
            logger.warning(f"Aucun JSON trouvé dans la réponse : {raw[:200]}")
            return []
        try:
            data = json.loads(match.group())
            memories = data.get("memories", [])
            validated = []
            for m in memories:
                if isinstance(m, dict) and m.get("content", "").strip():
                    validated.append({
                        "content": m["content"].strip(),
                        "category": m.get("category", "général").lower(),
                        "importance": max(1, min(10, int(m.get("importance", 5)))),
                    })
            return validated
        except Exception as e:
            logger.warning(f"Erreur parsing JSON mémoire : {e} — raw: {raw[:200]}")
            return []


memory_extractor = MemoryExtractor()
