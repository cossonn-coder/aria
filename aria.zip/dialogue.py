import logging
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Optional

from agents.base import AgentContext

logger = logging.getLogger(__name__)


@dataclass
class DialogueState:
    ctx: AgentContext
    questions: list[dict]   # [{"question": "...", "why": "..."}]
    current_idx: int = 0
    answers: list[str] = field(default_factory=list)
    started_at: datetime = field(default_factory=datetime.now)
    completed: bool = False


class DialogueManager:
    def __init__(self):
        from config import config
        self.cfg = config
        self._sessions: dict[int, DialogueState] = {}

    def start(self, user_id: int, ctx: AgentContext) -> Optional[str]:
        """
        Démarre le dialogue si des questions existent.
        Retourne la première question ou None si pas de questions.
        """
        missing = ctx.extra.get("analyst_raw", {}).get("missing_info", [])
        if not missing:
            return None

        questions = missing[:self.cfg.max_dialogue_questions]
        state = DialogueState(ctx=ctx, questions=questions)
        self._sessions[user_id] = state
        return self._format_question(state)

    def handle_answer(self, user_id: int, answer: str) -> tuple[Optional[str], Optional[AgentContext]]:
        """
        Traite une réponse.
        Retourne (prochaine_question, None) ou (None, ctx_complété).
        """
        state = self._sessions.get(user_id)
        if not state:
            return None, None

        # Vérification expiration
        timeout = timedelta(minutes=self.cfg.dialogue_timeout_minutes)
        if datetime.now() - state.started_at > timeout:
            logger.info(f"Dialogue expiré pour user {user_id}")
            del self._sessions[user_id]
            return None, state.ctx

        state.answers.append(answer)
        state.current_idx += 1
        state.ctx.answers = state.answers

        if state.current_idx >= len(state.questions):
            state.completed = True
            del self._sessions[user_id]
            return None, state.ctx

        return self._format_question(state), None

    def skip(self, user_id: int) -> tuple[Optional[str], Optional[AgentContext]]:
        """Passe à la question suivante ou termine."""
        return self.handle_answer(user_id, "[passé]")

    def cancel(self, user_id: int) -> Optional[AgentContext]:
        """Annule le dialogue, retourne le contexte partiel."""
        state = self._sessions.pop(user_id, None)
        if state:
            state.ctx.answers = state.answers
            return state.ctx
        return None

    def has_active(self, user_id: int) -> bool:
        return user_id in self._sessions

    def _format_question(self, state: DialogueState) -> str:
        q = state.questions[state.current_idx]
        total = len(state.questions)
        idx = state.current_idx + 1
        return (
            f"❓ Question {idx}/{total}\n\n"
            f"{q['question']}\n\n"
            f"_(Réponds librement · /skip pour passer · /cancel pour annuler)_"
        )


dialogue_manager = DialogueManager()
