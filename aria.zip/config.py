import os
from dataclasses import dataclass
from pathlib import Path
from dotenv import load_dotenv

BASE_DIR = Path(__file__).parent
load_dotenv(BASE_DIR.parent / "groq" / ".env")  # charge ~/groq/.env


@dataclass
class Config:
    # ── Telegram ──────────────────────────────────────────────────────────────
    telegram_bot_token: str = ""
    allowed_user_id: int = 0

    # ── Clés API ──────────────────────────────────────────────────────────────
    gemini_api_key: str = ""
    groq_api_key: str = ""
    mistral_api_key: str = ""
    cerebras_api_key: str = ""
    sambanova_api_key: str = ""
    openrouter_api_key: str = ""

    # ── Modèles ───────────────────────────────────────────────────────────────
    groq_model: str = "llama-3.3-70b-versatile"
    cerebras_model: str = "llama3.3-70b"
    gemini_model: str = "gemini-1.5-flash"
    mistral_model: str = "mistral-small-latest"
    sambanova_model: str = "DeepSeek-R1-Distill-Llama-70B"
    embedding_model: str = "models/text-embedding-004"

    # ── Mémoire ChromaDB ──────────────────────────────────────────────────────
    chroma_path: str = ""
    max_memories_injected: int = 10
    memory_relevance_threshold: float = 0.55
    extract_every_n_turns: int = 5

    # ── Agents ────────────────────────────────────────────────────────────────
    max_dialogue_questions: int = 3
    dialogue_timeout_minutes: int = 30

    # ── Fichiers d'identité ───────────────────────────────────────────────────
    soul_path: str = ""
    user_path: str = ""
    memory_md_path: str = ""
    pending_path: str = ""

    # ── OpenRouter ────────────────────────────────────────────────────────────
    openrouter_models_refresh_hours: int = 24

    # ── Conversation ──────────────────────────────────────────────────────────
    max_history_turns: int = 10

    def __post_init__(self):
        self.telegram_bot_token = os.getenv("TELEGRAM_BOT_TOKEN", "")
        self.allowed_user_id = int(os.getenv("ALLOWED_USER_ID", "0"))
        self.gemini_api_key = os.getenv("GEMINI_API_KEY", "")
        self.groq_api_key = os.getenv("GROQ_API_KEY", "")
        self.mistral_api_key = os.getenv("MISTRAL_API_KEY", "")
        self.cerebras_api_key = os.getenv("CEREBRAS_API_KEY", "")
        self.sambanova_api_key = os.getenv("SAMBANOVA_API_KEY", "")
        self.openrouter_api_key = os.getenv("OPENROUTER_API_KEY", "")

        self.chroma_path = str(BASE_DIR / "chroma_db")
        self.soul_path = str(BASE_DIR / "soul.md")
        self.user_path = str(BASE_DIR / "user.md")
        self.memory_md_path = str(BASE_DIR / "memory.md")
        self.pending_path = str(BASE_DIR / "pending_memories.json")


config = Config()
