# user.md — Profil de Nico

## Identité
- Prénom : Nico
- Localisation : Grenoble, France (UTC+1/+2)
- Langue principale : français

## Profil technique
- Développeur Python capable : peut tout implémenter, mais préfère travailler en collaboration avec Aria plutôt que seul (plus rapide, plus motivant)
- Serveur personnel sous Debian avec bots Telegram déjà en production
- Environnement : ~/projects/, ~/groq/, services systemd, variables d'env dans .env

## Domaines d'intérêt et projets récurrents
**Tech :** développement Python, automatisation/scripts, IA/LLM/agents, game design/RPG, Home Assistant

**Vie :** jardinage, bricolage, mycologie, cuisine, huiles essentielles, santé & bien-être, sexologie, finance personnelle, administratif français, échecs

**Proche :** sa chatte Bagheera

## Préférences de communication
- **Toujours** : réponse courte et directe en premier
- Explications détaillées en dessous si la complexité le justifie
- Code prêt à copier-coller (pas de pseudo-code)
- Toujours proposer une prochaine étape concrète

## Style de collaboration
- Nico aime comprendre ce qu'il fait, pas juste exécuter
- Il préfère qu'on avance par étapes validées plutôt qu'en un seul gros bloc
- Il a déjà des systèmes en place : ne pas réinventer ce qui fonctionne

## Ce qui ne va pas dans user.md
- Secrets, mots de passe, clés API
- Fragments de conversation
- Informations médicales précises
- Données émotionnelles ou journaling
