"""
Orchestrateur du pipeline /idea :
AnalystAgent → DialogueManager → PlannerAgent → CriticAgent → Synthèse
"""

import logging
from typing import Optional

from agents.analyst import AnalystAgent
from agents.base import AgentContext
from agents.critic import CriticAgent
from agents.dialogue import dialogue_manager
from agents.planner import PlannerAgent
from llm_router import LLMRole, router
from memory.extractor import memory_extractor
from memory.store import memory_store

logger = logging.getLogger(__name__)

SEPARATOR = "─" * 30

SYNTHESIS_PROMPT = """Tu es Aria, l'assistant personnel de Nico. Synthétise ce travail en un message Telegram lisible.

IDÉE : {idea}

ANALYSE : {analysis}

PLAN : {plan}

CRITIQUE : {critique}

Rédige une synthèse en français (<400 mots) :
- Points clés en bullet points
- Les 2-3 actions immédiates les plus importantes
- Une question finale engageante pour faire avancer Nico

Sois direct, concis, sans fioritures. Pas d'introduction générique.
"""


class IdeaPipeline:
    def __init__(self):
        self.analyst = AnalystAgent()
        self.planner = PlannerAgent()
        self.critic = CriticAgent()

    async def start(self, user_id: int, idea: str) -> tuple[str, bool]:
        """
        Démarre le pipeline.
        Retourne (message, dialogue_actif).
        """
        # Récupère les mémoires pertinentes
        memories = memory_store.search(idea, user_id)

        ctx = AgentContext(user_id=user_id, raw_idea=idea, memories=memories)

        # Analyse
        ctx = self.analyst.run(ctx)

        # Dialogue si questions manquantes
        first_question = dialogue_manager.start(user_id, ctx)
        if first_question:
            return first_question, True

        # Pas de questions → pipeline direct
        result = await self._run_pipeline(ctx)
        return result, False

    async def handle_answer(self, user_id: int, answer: str) -> tuple[str, bool]:
        """
        Traite une réponse durant le dialogue.
        Retourne (message, dialogue_actif).
        """
        next_q, completed_ctx = dialogue_manager.handle_answer(user_id, answer)

        if next_q:
            return next_q, True

        if completed_ctx:
            result = await self._run_pipeline(completed_ctx)
            return result, False

        return "Erreur dans le pipeline de dialogue.", False

    async def _run_pipeline(self, ctx: AgentContext) -> str:
        # Planification
        ctx = self.planner.run(ctx)
        # Critique
        ctx = self.critic.run(ctx)
        # Synthèse
        synthesis = self._synthesize(ctx)
        # Extraction mémoire (en arrière-plan, candidates pour validation)
        self._extract_memories(ctx)
        return self._build_message(synthesis, ctx)

    def _synthesize(self, ctx: AgentContext) -> str:
        try:
            response = router.complete(
                prompt=SYNTHESIS_PROMPT.format(
                    idea=ctx.raw_idea,
                    analysis=ctx.analysis,
                    plan=ctx.plan,
                    critique=ctx.critique,
                ),
                role=LLMRole.FAST,
                temperature=0.6,
                max_tokens=600,
            )
            return response.text
        except Exception as e:
            logger.error(f"Synthèse erreur : {e}")
            return f"Synthèse indisponible : {e}"

    def _build_message(self, synthesis: str, ctx: AgentContext) -> str:
        parts = [
            synthesis,
            SEPARATOR,
            "📋 **Plan détaillé**",
            ctx.plan or "Non disponible.",
            SEPARATOR,
            "🔍 **Analyse critique**",
            ctx.critique or "Non disponible.",
        ]
        return "\n\n".join(parts)

    def _extract_memories(self, ctx: AgentContext):
        """Extrait des mémoires depuis le pipeline et les met en attente de validation."""
        fake_conv = [
            {"role": "user", "content": f"Mon idée : {ctx.raw_idea}"},
            {"role": "assistant", "content": ctx.analysis},
        ]
        if ctx.answers:
            for a in ctx.answers:
                fake_conv.append({"role": "user", "content": a})
        memories = memory_extractor.extract(fake_conv)
        if memories:
            memory_store.add_pending(memories, ctx.user_id)
            logger.info(f"{len(memories)} mémoires candidates ajoutées (pipeline)")


idea_pipeline = IdeaPipeline()
