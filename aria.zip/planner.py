import logging

from agents.base import AgentContext, BaseAgent
from llm_router import LLMRole, router

logger = logging.getLogger(__name__)

PLANNER_PROMPT = """Tu es un agent planificateur expert. Crée un plan d'action complet et réaliste.

{memories}

IDÉE ORIGINALE : {idea}

ANALYSE :
{analysis}

{answers}

Génère un plan d'action structuré en Markdown avec :
- Des phases claires (Phase 1, Phase 2…)
- Des étapes concrètes et actionnables pour chaque phase
- Les ressources/outils nécessaires
- Des critères de succès mesurables
- Une estimation de temps pour chaque phase

Sois précis, pratique et adapté au contexte de Nico (développeur Python, serveur Debian, projets IA).
Réponds directement en Markdown, sans introduction ni conclusion.
"""


class PlannerAgent(BaseAgent):
    def run(self, ctx: AgentContext) -> AgentContext:
        prompt = PLANNER_PROMPT.format(
            memories=self._format_memories(ctx),
            idea=ctx.raw_idea,
            analysis=ctx.analysis or "Non disponible.",
            answers=self._format_answers(ctx),
        )
        try:
            response = router.complete(
                prompt=prompt,
                role=LLMRole.DEEP,
                temperature=0.5,
                max_tokens=2000,
            )
            ctx.plan = response.text
        except Exception as e:
            logger.error(f"PlannerAgent erreur : {e}")
            ctx.plan = f"Plan indisponible : {e}"
        return ctx
