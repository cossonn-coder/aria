"""
Aria — Bot Telegram personnel de Nico
Point d'entrée principal.
"""

import asyncio
import logging
from pathlib import Path

from telegram import Update
from telegram.ext import (
    Application,
    CommandHandler,
    ContextTypes,
    MessageHandler,
    filters,
)

from agents.dialogue import dialogue_manager
from agents.orchestrator import idea_pipeline
from config import config
from llm_router import LLMRole, router
from memory.extractor import memory_extractor
from memory.store import memory_store

logging.basicConfig(
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)

# ── Historique de conversation en mémoire ─────────────────────────────────────
conversation_history: list[dict] = []
turn_counter: int = 0


# ── Chargement des fichiers d'identité ────────────────────────────────────────

def _load_identity_files() -> str:
    parts = []
    for path_attr, label in [
        (config.soul_path, "CONSTITUTION"),
        (config.user_path, "PROFIL UTILISATEUR"),
        (config.memory_md_path, "MÉMOIRE DURABLE"),
    ]:
        p = Path(path_attr)
        if p.exists():
            content = p.read_text(encoding="utf-8").strip()
            if content:
                parts.append(f"## {label}\n{content}")
    return "\n\n".join(parts)


# ── Vérification d'accès ──────────────────────────────────────────────────────

def _is_allowed(update: Update) -> bool:
    if config.allowed_user_id == 0:
        return True
    return update.effective_user.id == config.allowed_user_id


# ── Système prompt dynamique ──────────────────────────────────────────────────

def _build_system(memories_text: str = "") -> str:
    identity = _load_identity_files()
    parts = [identity]
    if memories_text:
        parts.append(memories_text)
    return "\n\n".join(filter(bool, parts))


# ── Chat standard ─────────────────────────────────────────────────────────────

async def _chat(user_id: int, user_message: str) -> tuple[str, str]:
    global conversation_history, turn_counter

    # Recherche mémoires pertinentes
    memories = await asyncio.to_thread(
        memory_store.search, user_message, user_id
    )
    memories_text = memory_store.format_for_prompt(memories)
    system = _build_system(memories_text)

    # Construit le prompt avec historique
    history_text = ""
    if conversation_history:
        recent = conversation_history[-config.max_history_turns * 2:]
        history_text = "\n".join(
            f"{'NICO' if m['role'] == 'user' else 'ARIA'} : {m['content']}"
            for m in recent
        )

    prompt = f"{history_text}\nNICO : {user_message}\nARIA :" if history_text else user_message

    response = await asyncio.to_thread(
        router.complete,
        prompt=prompt,
        role=LLMRole.DEEP,
        system=system,
        temperature=0.7,
        max_tokens=1000,
    )

    # Met à jour l'historique
    conversation_history.append({"role": "user", "content": user_message})
    conversation_history.append({"role": "assistant", "content": response.text})
    # Garde seulement les N derniers turns
    max_msgs = config.max_history_turns * 2
    if len(conversation_history) > max_msgs:
        conversation_history = conversation_history[-max_msgs:]

    turn_counter += 1

    # Auto-extraction en arrière-plan
    if turn_counter % config.extract_every_n_turns == 0:
        asyncio.create_task(_auto_extract(user_id))

    model_label = response.model_used.split("/")[-1][:25]
    n_mem = len(memories)
    footer = f"\n\n🧠 {n_mem} mémoire(s) · _{model_label}_"
    return response.text + footer, response.model_used


async def _auto_extract(user_id: int):
    """Extraction automatique des mémoires depuis la conversation."""
    recent = conversation_history[-config.extract_every_n_turns * 2:]
    candidates = await asyncio.to_thread(memory_extractor.extract, recent)
    if candidates:
        memory_store.add_pending(candidates, user_id)
        logger.info(f"{len(candidates)} mémoires candidates extraites auto")


# ── Handlers ──────────────────────────────────────────────────────────────────

async def cmd_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not _is_allowed(update):
        return
    await update.message.reply_text(
        "👋 Bonjour Nico, je suis Aria.\n\n"
        "Commandes disponibles :\n"
        "/idea <ton idée> — pipeline multi-agents\n"
        "/memories — voir tes mémoires\n"
        "/confirm — valider les mémoires en attente\n"
        "/reject — rejeter les mémoires en attente\n"
        "/remember — forcer une extraction maintenant\n"
        "/models — voir les modèles disponibles\n"
        "/stats — statistiques\n"
        "/reset — effacer toutes les mémoires\n"
        "/help — cette aide"
    )


async def cmd_help(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await cmd_start(update, context)


async def cmd_idea(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not _is_allowed(update):
        return
    if not context.args:
        await update.message.reply_text("Usage : /idea <décris ton idée>")
        return

    idea = " ".join(context.args)
    user_id = update.effective_user.id

    await update.message.reply_text("⚙️ Analyse en cours…")

    try:
        message, dialogue_active = await idea_pipeline.start(user_id, idea)
        await update.message.reply_text(message, parse_mode="Markdown")
    except Exception as e:
        logger.error(f"Erreur pipeline idea : {e}")
        await update.message.reply_text(f"❌ Erreur : {e}")


async def cmd_skip(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not _is_allowed(update):
        return
    user_id = update.effective_user.id
    if not dialogue_manager.has_active(user_id):
        await update.message.reply_text("Pas de dialogue actif.")
        return
    next_q, completed_ctx = dialogue_manager.skip(user_id)
    if next_q:
        await update.message.reply_text(next_q, parse_mode="Markdown")
    elif completed_ctx:
        await update.message.reply_text("⚙️ Pipeline en cours…")
        result = await idea_pipeline._run_pipeline(completed_ctx)
        await update.message.reply_text(result, parse_mode="Markdown")


async def cmd_cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not _is_allowed(update):
        return
    user_id = update.effective_user.id
    ctx = dialogue_manager.cancel(user_id)
    if ctx:
        await update.message.reply_text("⚙️ Pipeline en cours sans les réponses…")
        result = await idea_pipeline._run_pipeline(ctx)
        await update.message.reply_text(result, parse_mode="Markdown")
    else:
        await update.message.reply_text("Pas de dialogue actif à annuler.")


async def cmd_confirm(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not _is_allowed(update):
        return
    user_id = update.effective_user.id
    pending = memory_store.get_pending(user_id)
    if not pending:
        await update.message.reply_text("Aucune mémoire en attente de validation.")
        return

    # Si des indices sont passés (/confirm 1 3), valide seulement ceux-là
    if context.args:
        try:
            indices = [int(a) - 1 for a in context.args]
            added = memory_store.confirm_pending(user_id, indices)
            await update.message.reply_text(f"✅ {added} mémoire(s) validée(s).")
        except ValueError:
            await update.message.reply_text("Usage : /confirm ou /confirm 1 2 3")
        return

    # Affiche la liste pour permettre une sélection
    lines = ["📋 *Mémoires en attente — /confirm all ou /confirm 1 2 3 :*\n"]
    for i, m in enumerate(pending, 1):
        lines.append(f"{i}. [{m.get('category', '?')}] {m['content']} _(importance: {m.get('importance', 5)})_")
    lines.append("\n/confirm all — tout valider · /reject — tout rejeter")
    await update.message.reply_text("\n".join(lines), parse_mode="Markdown")


async def cmd_confirm_all(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Raccourci /confirm all via le texte."""
    pass  # géré dans handle_message


async def cmd_reject(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not _is_allowed(update):
        return
    user_id = update.effective_user.id
    memory_store.reject_pending(user_id)
    await update.message.reply_text("🗑 Mémoires en attente supprimées.")


async def cmd_memories(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not _is_allowed(update):
        return
    user_id = update.effective_user.id
    memories = memory_store.get_all(user_id)
    if not memories:
        await update.message.reply_text("Aucune mémoire stockée pour l'instant.")
        return
    by_cat: dict[str, list] = {}
    for m in memories:
        by_cat.setdefault(m["category"], []).append(m)
    lines = [f"🧠 *{len(memories)} mémoire(s) stockée(s)*\n"]
    for cat, items in by_cat.items():
        lines.append(f"*{cat.capitalize()}*")
        for m in items:
            lines.append(f"- {m['content']} _(i:{m['importance']})_")
        lines.append("")
    await update.message.reply_text("\n".join(lines), parse_mode="Markdown")


async def cmd_remember(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not _is_allowed(update):
        return
    user_id = update.effective_user.id
    await update.message.reply_text("🔍 Extraction en cours…")
    await _auto_extract(user_id)
    pending = memory_store.get_pending(user_id)
    n = len(pending)
    if n:
        await update.message.reply_text(
            f"✅ {n} mémoire(s) candidate(s) extraite(s). Utilise /confirm pour valider."
        )
    else:
        await update.message.reply_text("Rien de mémorable extrait pour l'instant.")


async def cmd_extract(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await cmd_remember(update, context)


async def cmd_models(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not _is_allowed(update):
        return
    router_info = [
        "🤖 *Modèles configurés*\n",
        f"FAST : {config.groq_model} → {config.cerebras_model} → OpenRouter → {config.gemini_model}",
        f"DEEP : {config.gemini_model} → {config.sambanova_model} → OpenRouter → {config.groq_model}",
        f"CREATIVE : {config.mistral_model} → OpenRouter → {config.gemini_model} → {config.cerebras_model}",
    ]
    or_models = router._openrouter_models
    if or_models:
        router_info.append(f"\nOpenRouter gratuits chargés : {len(or_models)}")
        router_info.append(", ".join(or_models[:3]) + ("…" if len(or_models) > 3 else ""))
    await update.message.reply_text("\n".join(router_info), parse_mode="Markdown")


async def cmd_stats(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not _is_allowed(update):
        return
    user_id = update.effective_user.id
    n_mem = memory_store.count(user_id)
    n_pending = len(memory_store.get_pending(user_id))
    await update.message.reply_text(
        f"📊 *Statistiques*\n\n"
        f"Mémoires stockées : {n_mem}\n"
        f"Mémoires en attente : {n_pending}\n"
        f"Tours de conversation : {turn_counter}",
        parse_mode="Markdown",
    )


async def cmd_reset(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not _is_allowed(update):
        return
    user_id = update.effective_user.id
    memory_store.reset(user_id)
    global conversation_history, turn_counter
    conversation_history = []
    turn_counter = 0
    await update.message.reply_text("🗑 Mémoires et historique effacés.")


async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not _is_allowed(update):
        return

    user_id = update.effective_user.id
    text = update.message.text.strip()

    # Raccourci "confirm all"
    if text.lower() in ("confirm all", "/confirm all"):
        added = memory_store.confirm_pending(user_id)
        await update.message.reply_text(f"✅ {added} mémoire(s) validée(s).")
        return

    # Priorité 1 : dialogue actif
    if dialogue_manager.has_active(user_id):
        next_q, completed_ctx = dialogue_manager.handle_answer(user_id, text)
        if next_q:
            await update.message.reply_text(next_q, parse_mode="Markdown")
            return
        if completed_ctx:
            await update.message.reply_text("⚙️ Pipeline en cours…")
            result = await idea_pipeline._run_pipeline(completed_ctx)
            await update.message.reply_text(result, parse_mode="Markdown")
            return

    # Priorité 2 : chat standard
    try:
        reply, _ = await _chat(user_id, text)
        await update.message.reply_text(reply, parse_mode="Markdown")
    except Exception as e:
        logger.error(f"Erreur chat : {e}")
        await update.message.reply_text(f"❌ Erreur : {e}")


# ── Main ──────────────────────────────────────────────────────────────────────

def main():
    if not config.telegram_bot_token:
        raise ValueError("TELEGRAM_BOT_TOKEN manquant dans le .env")

    app = Application.builder().token(config.telegram_bot_token).build()

    app.add_handler(CommandHandler("start", cmd_start))
    app.add_handler(CommandHandler("help", cmd_help))
    app.add_handler(CommandHandler("idea", cmd_idea))
    app.add_handler(CommandHandler("skip", cmd_skip))
    app.add_handler(CommandHandler("cancel", cmd_cancel))
    app.add_handler(CommandHandler("confirm", cmd_confirm))
    app.add_handler(CommandHandler("reject", cmd_reject))
    app.add_handler(CommandHandler("memories", cmd_memories))
    app.add_handler(CommandHandler("remember", cmd_remember))
    app.add_handler(CommandHandler("extract", cmd_extract))
    app.add_handler(CommandHandler("models", cmd_models))
    app.add_handler(CommandHandler("stats", cmd_stats))
    app.add_handler(CommandHandler("reset", cmd_reset))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))

    logger.info("Aria démarre…")
    app.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
