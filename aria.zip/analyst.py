import json
import logging
import re

from agents.base import AgentContext, BaseAgent
from llm_router import LLMRole, router

logger = logging.getLogger(__name__)

ANALYST_PROMPT = """Tu es un agent analyste expert. Analyse l'idée de l'utilisateur et décompose-la de façon structurée.

{memories}

IDÉE : {idea}

Réponds UNIQUEMENT avec un JSON valide (sans backticks, sans texte autour) :
{{
  "domains": ["domaine1", "domaine2"],
  "complexity": "faible|moyenne|élevée",
  "core_intent": "intention principale en une phrase",
  "sub_problems": ["sous-problème 1", "sous-problème 2"],
  "assumptions": ["hypothèse 1", "hypothèse 2"],
  "missing_info": [
    {{"question": "...", "why": "pourquoi c'est important", "priority": 1}}
  ],
  "quick_wins": ["action rapide 1", "action rapide 2"],
  "risks": ["risque 1", "risque 2"]
}}

Trie missing_info par priorité (1 = le plus important). Maximum 5 éléments par liste.
"""


class AnalystAgent(BaseAgent):
    def run(self, ctx: AgentContext) -> AgentContext:
        prompt = ANALYST_PROMPT.format(
            memories=self._format_memories(ctx),
            idea=ctx.raw_idea,
        )
        try:
            response = router.complete(
                prompt=prompt,
                role=LLMRole.DEEP,
                temperature=0.3,
                max_tokens=1200,
            )
            data = self._parse(response.text)
            ctx.extra["analyst_raw"] = data
            ctx.domain_tags = data.get("domains", [])
            ctx.analysis = self._to_markdown(data)
        except Exception as e:
            logger.error(f"AnalystAgent erreur : {e}")
            ctx.analysis = f"Analyse indisponible : {e}"
        return ctx

    def _parse(self, raw: str) -> dict:
        clean = re.sub(r"```(?:json)?", "", raw).strip()
        match = re.search(r"\{.*\}", clean, re.DOTALL)
        if not match:
            return {}
        try:
            return json.loads(match.group())
        except Exception as e:
            logger.warning(f"Analyst JSON parse error : {e}")
            return {}

    def _to_markdown(self, d: dict) -> str:
        if not d:
            return "Analyse non disponible."
        lines = [
            f"**Intention principale :** {d.get('core_intent', '?')}",
            f"**Complexité :** {d.get('complexity', '?')}",
            f"**Domaines :** {', '.join(d.get('domains', []))}",
        ]
        if d.get("sub_problems"):
            lines += ["\n**Sous-problèmes :"]
            lines += [f"- {s}" for s in d["sub_problems"]]
        if d.get("quick_wins"):
            lines += ["\n**Actions rapides :"]
            lines += [f"- {q}" for q in d["quick_wins"]]
        if d.get("risks"):
            lines += ["\n**Risques identifiés :"]
            lines += [f"- {r}" for r in d["risks"]]
        return "\n".join(lines)
